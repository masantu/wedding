<div class="site-info">
	<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'affinity' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'affinity' ), 'WordPress' ); ?></a>
	<span class="sep"> &diams; </span>
	<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'affinity' ), 'affinity', '<a href="http://wordpress.com/themes/" rel="designer">Automattic</a>' ); ?>
</div><!-- .site-info -->
